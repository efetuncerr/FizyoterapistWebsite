-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 31, 2023 at 02:49 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `desc` varchar(1000) NOT NULL,
  `img` varchar(255) NOT NULL,
  `date` datetime DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `cat` varchar(45) DEFAULT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `desc`, `img`, `date`, `uid`, `cat`, `firstname`, `lastname`, `phone`, `email`) VALUES
(80, 'Test', '123123', '', '2023-08-23 08:27:54', 11, 'Cat 6', 'efe', 'tuncer', '123', 'efetuncerr@hotmail.com'),
(81, 'asdasdteastastast', 'sdasdasd', '', '2023-08-23 15:29:21', 11, 'Cat 2', 'asdasdqwe', 'etast', '05338567226', 'qweqwe'),
(82, 'deneme efe son', '123123', '', '2023-08-24 10:03:50', 100, 'Cat 1', 'aa', 'aa', '123123', 'adasd'),
(83, 'asda', 'asd', '', '2023-08-25 08:34:02', 8, 'Cat 1', 'asd', '123', '05338567226', '123asd'),
(84, 'asdasdTetstst', 'asdasd', '', '2023-08-25 14:33:42', 11, 'Cat 2', 'asdasd', 'asdasd', '123', '123'),
(85, '', '', '', '2023-08-25 14:39:45', 11, '', '', '', '', ''),
(86, 'almina.dsy@gmail.com', 'asd', '', '2023-08-29 08:43:14', 11, 'Cat 5', 'almina.dsy@gmail.com', 'almina.dsy@gmail.com', '123123', 'almina.dsy@gmail.com'),
(87, 'denemeDENEME', '123123', '', '2023-08-31 09:52:31', 104, 'Cat 1', 'denemeefe', 'tuncer', '122', 'deneme@hotmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `foreign key` (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `foreign key` FOREIGN KEY (`uid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
