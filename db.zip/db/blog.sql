-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 31, 2023 at 02:48 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `desc` varchar(1000) NOT NULL,
  `img` varchar(255) NOT NULL,
  `date` datetime DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `cat` varchar(45) DEFAULT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `desc`, `img`, `date`, `uid`, `cat`, `firstname`, `lastname`, `phone`, `email`) VALUES
(80, 'Test', '123123', '', '2023-08-23 08:27:54', 11, 'Cat 6', 'efe', 'tuncer', '123', 'efetuncerr@hotmail.com'),
(81, 'asdasdteastastast', 'sdasdasd', '', '2023-08-23 15:29:21', 11, 'Cat 2', 'asdasdqwe', 'etast', '05338567226', 'qweqwe'),
(82, 'deneme efe son', '123123', '', '2023-08-24 10:03:50', 100, 'Cat 1', 'aa', 'aa', '123123', 'adasd'),
(83, 'asda', 'asd', '', '2023-08-25 08:34:02', 8, 'Cat 1', 'asd', '123', '05338567226', '123asd'),
(84, 'asdasdTetstst', 'asdasd', '', '2023-08-25 14:33:42', 11, 'Cat 2', 'asdasd', 'asdasd', '123', '123'),
(85, '', '', '', '2023-08-25 14:39:45', 11, '', '', '', '', ''),
(86, 'almina.dsy@gmail.com', 'asd', '', '2023-08-29 08:43:14', 11, 'Cat 5', 'almina.dsy@gmail.com', 'almina.dsy@gmail.com', '123123', 'almina.dsy@gmail.com'),
(87, 'denemeDENEME', '123123', '', '2023-08-31 09:52:31', 104, 'Cat 1', 'denemeefe', 'tuncer', '122', 'deneme@hotmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(45) NOT NULL,
  `surname` varchar(45) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `img` varchar(255) NOT NULL,
  `role` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `surname`, `email`, `password`, `phone`, `img`, `role`) VALUES
(8, 'admin', '', 'efetuncerr@hotmail.com', '$2a$10$g.WzFCbl.E4I75Jm.9kscOYE8TWkqy.s.1UMuwSAbaPxxJAvv95Ae', '', '', 0),
(9, 'efe', '', 'alsdkasd@hotmail.com', '$2a$10$PbJ.mw5pMlb0961tBndz/uoJ7WAZqk1vHYVb35ZZkjGBq/LJxdP4.', '', '', 0),
(11, 'test', '', 'test', '$2a$10$kzV0fztOQR8/MsYTxXZOM.94FhS3lF71AnXG4Tt06Rhc2jzwC.9zi', '', '', 1),
(18, 'user', 'aa', 'aa', '$2a$10$HuZJ5Nv3lqkm77w1gaLPuuQq0.eyrYTlOVC1j4vsHb9IsAplgymjO', '123', '', 0),
(99, 'adminefe', 'efe', 'efetuncerrr@hotmail.com', '123', '123123', '', 1),
(100, 'denemekk', 'kk', 'kk', '$2a$10$A8MuGY.tnaVgpxYvQZHWh.zBVJmwcCuMz8/LyihcQg0O7D4RjSd0S', '123', '', 0),
(101, 'adminadmin', 'efe', 'efetaasdasdşl@hotmail.com', '$2a$10$Th47UBvxS1FaCCZa/HdNPOOadOrVXfJ5jH6UhoYyZ7ObvfriT6XLu', '123123', '', 0),
(102, 'adasdaxsasd', '231dasd', 'asdsda', '$2a$10$ke3vjbkl2F2jNkQC4pEhfeR7yzJNK6P8LEK4a.LNH.vziCs9ujp8q', '123123123', '', 0),
(103, 'admin123', 'admin123', 'efe', '$2a$10$4ZVTaaZLTo0fxKPd8MSa4uXkGEiMuaP5GRzpZ38rFb5rMm1c0S9Ba', '123', '', 0),
(104, 'denemeefe', 'deneme', 'deneme@deneme.com', '$2a$10$Hy5mJm.R/dEbRCvG.DG4Ku94tII1tkyn2ol5yKnaT0YTvrQWkBPHS', '123', '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `foreign key` (`uid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `foreign key` FOREIGN KEY (`uid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
