-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 31, 2023 at 02:50 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(45) NOT NULL,
  `surname` varchar(45) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `img` varchar(255) NOT NULL,
  `role` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `surname`, `email`, `password`, `phone`, `img`, `role`) VALUES
(8, 'admin', '', 'efetuncerr@hotmail.com', '$2a$10$g.WzFCbl.E4I75Jm.9kscOYE8TWkqy.s.1UMuwSAbaPxxJAvv95Ae', '', '', 0),
(9, 'efe', '', 'alsdkasd@hotmail.com', '$2a$10$PbJ.mw5pMlb0961tBndz/uoJ7WAZqk1vHYVb35ZZkjGBq/LJxdP4.', '', '', 0),
(11, 'test', '', 'test', '$2a$10$kzV0fztOQR8/MsYTxXZOM.94FhS3lF71AnXG4Tt06Rhc2jzwC.9zi', '', '', 1),
(18, 'user', 'aa', 'aa', '$2a$10$HuZJ5Nv3lqkm77w1gaLPuuQq0.eyrYTlOVC1j4vsHb9IsAplgymjO', '123', '', 0),
(99, 'adminefe', 'efe', 'efetuncerrr@hotmail.com', '123', '123123', '', 1),
(100, 'denemekk', 'kk', 'kk', '$2a$10$A8MuGY.tnaVgpxYvQZHWh.zBVJmwcCuMz8/LyihcQg0O7D4RjSd0S', '123', '', 0),
(101, 'adminadmin', 'efe', 'efetaasdasdşl@hotmail.com', '$2a$10$Th47UBvxS1FaCCZa/HdNPOOadOrVXfJ5jH6UhoYyZ7ObvfriT6XLu', '123123', '', 0),
(102, 'adasdaxsasd', '231dasd', 'asdsda', '$2a$10$ke3vjbkl2F2jNkQC4pEhfeR7yzJNK6P8LEK4a.LNH.vziCs9ujp8q', '123123123', '', 0),
(103, 'admin123', 'admin123', 'efe', '$2a$10$4ZVTaaZLTo0fxKPd8MSa4uXkGEiMuaP5GRzpZ38rFb5rMm1c0S9Ba', '123', '', 0),
(104, 'denemeefe', 'deneme', 'deneme@deneme.com', '$2a$10$Hy5mJm.R/dEbRCvG.DG4Ku94tII1tkyn2ol5yKnaT0YTvrQWkBPHS', '123', '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
